#!/usr/bin/env bash

echo "Running ParaGone on a test dataset..."

# Remove folders from any previous runs:
folders_to_remove=('00_logs_and_reports'
                   '01_input_paralog_fasta_with_sanitised_filenames'
                   '02_alignments'
                   '03_alignments_trimmed'
                   '04_alignments_trimmed_hmmcleaned'
                   '05_trees_pre_quality_control'
                   '06_trees_trimmed'
                   '07_trees_trimmed_masked'
                   '08_trees_trimmed_masked_cut'
                   '09_sequences_from_qc_trees'
                   '10_sequences_from_qc_outgroups_added'
                   '11_pre_paralog_resolution_alignments'
                   '12_pre_paralog_resolution_alignments_trimmed'
                   '13_pre_paralog_resolution_trees'
                   '14_pruned_MO'
                   '15_pruned_MI'
                   '16_pruned_RT'
                   '17_selected_sequences_MO'
                   '18_selected_sequences_MI'
                   '19_selected_sequences_RT'
                   '20_MO_stripped_names'
                   '21_MI_stripped_names'
                   '22_RT_stripped_names'
                   '23_MO_final_alignments'
                   '24_MI_final_alignments'
                   '25_RT_final_alignments'
                   '26_MO_final_alignments_trimmed'
                   '27_MI_final_alignments_trimmed'
                   '28_RT_final_alignments_trimmed')


for folder in ${folders_to_remove[@]}
do
  echo "Attempting to removing folder ${folder}..."
  rm -r $folder 
done


##############################################################################################################
# Run the ParaGone pipeline
##############################################################################################################

# Check input sequences and align the paralog fasta files:
paragone check_and_align paralog_input --external_outgroups_file external_outgroups.fasta --internal_outgroup 80974 --pool 1 --threads 1

# Generate initial trees from the aligned paralog sequences:
paragone alignment_to_tree 04_alignments_trimmed_hmmcleaned --use_fasttree --pool 1 --threads 1

# Run quality control on the trees (trim tree tips, mask tree tips, cut deep paralogs) and extract fasta 
# sequences corresponding to the tree tips remaining:
paragone qc_trees_and_extract_fasta 04_alignments_trimmed_hmmcleaned --treeshrink_q_value 0.20


# Align the selected sequences, and generate trees for paralogy resolution algorithms:
paragone align_selected_and_tree 09_alignments_from_qc_trees 04_alignments_trimmed_hmmcleaned --use_fasttree --pool 1 --threads 1



# Prune paralogs with Yang and Smith algorithms:
paragone prune_paralogs --mo --rt --mi

# Create final alignments for concatenation or coalescent analysis:
paragone final_alignments --mo --rt --mi --pool 1 --threads 1 --keep_intermediate_files


# OPTIONAL: run the full pipeline with a single command:
# paragone full_pipeline paralog_input --external_outgroups_file external_outgroups.fasta --internal_outgroup 80974 --pool 1 --threads 1 --use_fasttree --treeshrink_q_value 0.20 --mo --rt --mi --keep_intermediate_files
 

##############################################################################################################

echo "DONE!"